from __future__ import print_function
import argparse
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
from data_set import WEIGHT_DATA_SET
from data import DATA,DATA_small, DATA_action, DATA_partial_logistic, DATA_partial_logistic_deep,DATA_partial_logistic_deep_gpu, DATA_partial_random, DATA_partial_action, DATA_learn_policy, DATA_defined_prob_eval,DATA_partial_logistic_deep_gpu_soften
from torchvision import transforms
import torchvision
import os
import copy
import torch.utils.data as data


import regression_utility as ru
import abstain_utility as au
from scipy import stats
import warnings
import copy
warnings.filterwarnings('ignore')

torch.set_default_tensor_type('torch.DoubleTensor')
mean0 = 0.6
var0 = 0.1
# d = 64

class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
class Net(nn.Module):
    def __init__(self, D_in, H, D_out):
        super(Net, self).__init__()
        self.D_in = D_in
        self.H = H
        self.D_out = D_out
        self.model = torch.nn.Sequential(
            torch.nn.utils.spectral_norm(torch.nn.Linear(self.D_in, self.H)),
            torch.nn.ReLU(),
            torch.nn.utils.spectral_norm(torch.nn.Linear(self.H, self.D_out)),
            )

    # def forward(self, x):
    #     return self.model(x)

    def forward(self, x):
#         self.map0(x)
        return x

class Net_MSE(nn.Module):
    def __init__(self, D_in, H, D_out):
        super(Net_MSE, self).__init__()
        self.D_in = D_in
        self.H = H
        self.D_out = D_out
        self.model = torch.nn.Sequential(
            torch.nn.utils.spectral_norm(torch.nn.Linear(self.D_in, self.D_out)),
            # torch.nn.ReLU(),
            # torch.nn.utils.spectral_norm(torch.nn.Linear(self.H, self.D_out)),
            )
    def forward(self, x):
        # print(x.shape)
        x = self.model(x)
        # print(x.shape)
        return x


def spectral_norm(module, name='weight'):
    SpectralNorm.apply(module, name)

def my_softmax(x):
    n = np.shape(x)[0]
    max_x, _ = torch.max(x, dim=1)
    max_x = torch.reshape(max_x, (n, 1))
    exp_x = torch.exp(x - max_x)
    p = exp_x / torch.reshape(torch.sum(exp_x, dim=1), (n, 1))
    p[p<10e-8] = 0
    return p


def train(args, model, loss_type, device, train_loader, n_class, optimizer, epoch):
    model.train()

    for batch_idx, (data, target, weight) in enumerate(train_loader):
        data, target = data.to(device), target.to(device)
        
        optimizer.zero_grad()
        output = model(data)
        weight = torch.tensor(weight).to(device)
       
        prob = au.my_softmax(torch.einsum('ij,i->ij', output, weight))
        
        
        y_onehot = torch.DoubleTensor(len(data), n_class).to(device)

        y_onehot.zero_()
        y_onehot.scatter_(1, target.reshape(len(data), 1), 1)

        output_last = au.log_gradient.apply(output, torch.tensor(prob), y_onehot)
       
        output_last.backward(torch.ones(output_last.shape).to(device),retain_graph=True)

#         optimizer.step()
        # if batch_idx % args.log_interval == 0:
        #     print('Train Epoch: {} [{}/{} ({:.0f}%)]'.format(
        #         epoch, batch_idx * len(data), len(train_loader.dataset),
        #         100. * batch_idx / len(train_loader)))

def train_regression(args, model, device, train_loader, optimizer, epoch, Myy, Myx, mean0, var0,d,lr1,lr2):
     
    model.train()
    lowerB = -1.0/(2*var0)

    grad_yy = torch.empty([0]).to(device)
    grad_yx = torch.empty([d + 1, 0]).to(device)

#     lr2 = 1
    lr2 = lr2 * (10 / (10 + np.sqrt(epoch)))

#     lr1 = 1
    lr1 = lr1 * (10 / (10 + np.sqrt(epoch)))
    grad_squ_1 = 0.00001
    grad_squ_2 = 0.00001
    for batch_idx, (data, target, weight) in enumerate(train_loader):
        
        data, target, weight = data.to(device), target.to(device), weight.to(device)
        optimizer.zero_grad()
        output = model(data)



        meanY, varY = ru.predict_regression(weight, Myy, Myx, output, mean0, var0)
        grad = ru.M_gradient_gpu(output, meanY, varY, target, Myy, Myx,d)

        grad_squ_1 = grad_squ_1 + grad[0]**2
        grad_squ_2 = grad_squ_2 + grad[1:]**2

        diff = lr1*(grad[0]) + 0.00000*Myy
        grad_yy = torch.cat([grad_yy, grad[0]])

        grad_yx = torch.cat([grad_yx, grad[1:]], 1)
        preM = Myy
        Myy = preM + lr1*(grad[0]/torch.sqrt(grad_squ_1)) + 0.00000*Myy

        while Myy[0][0] < lowerB:
            Myy = Myy + torch.abs(diff)/2

        Myx = Myx + lr2 *(grad[1:]/torch.sqrt(grad_squ_2)) + 0.00000*Myx
        bs = np.shape(output)[0]
        
        
        # output_last = ru.regression_gradient.apply(output, torch.tensor(Myx[0:-1]), torch.reshape(target, (bs, 1)), torch.reshape(meanY, (bs, 1)))
        # output_last.backward(torch.ones(output_last.shape).to(device),retain_graph=True)
        #
        #
        # optimizer.step()
        # if batch_idx % args.log_interval == 0:
        #     print('Train Epoch: {} [{}/{} ({:.0f}%)]'.format(
        #         epoch, batch_idx * len(data), len(train_loader.dataset),
        #         100. * batch_idx / len(train_loader)))
    # print(np.shape(grad_yy))
    # print(np.shape(grad_yx))
    # print('gradient:', np.linalg.norm(grad_yy))
    # print('gradient:', np.linalg.norm(grad_yx))

    return Myy, Myx,model, np.linalg.norm(grad_yy), np.linalg.norm(grad_yx)


def train_MSE(args, model, device, train_loader, optimizer, epoch):
     
    model.train()

    for batch_idx, (data, target) in enumerate(train_loader):
        
        data, target = data.to(device), target.to(device)
      
        optimizer.zero_grad()
        output = model(data)

        criterion = nn.MSELoss()
        loss = criterion(output, target)
        loss.backward()

        optimizer.step()
        return model
        # if batch_idx % args.log_interval == 0:
        #     print('Train Epoch: {} [{}/{} ({:.0f}%)]'.format(
        #         epoch, batch_idx * len(data), len(train_loader.dataset),
        #         100. * batch_idx / len(train_loader)))

def train_weight_MSE(args, model, device, train_loader, optimizer, epoch):
     
    model.train()

    for batch_idx, (data, target, weight) in enumerate(train_loader):
        
        data, target, weight = data.to(device), target.to(device), weight.to(device)
      
        optimizer.zero_grad()
        output = model(data)

        criterion = nn.MSELoss(reduce=False)

        loss = (1 - weight) * criterion(output, target.double())/(weight.float() * weight.float())
        # loss = criterion(output, target.double())

        loss = torch.mean(loss)
        loss.backward()

        optimizer.step()
    return model
        # if batch_idx % args.log_interval == 0:
        #     print('Train Epoch: {} [{}/{} ({:.0f}%)]'.format(
        #         epoch, batch_idx * len(data), len(train_loader.dataset),
        #         100. * batch_idx / len(train_loader)))

def test(args, model, loss_type, device, test_loader, n_class):
    model.eval()
    test_loss = 0
    correct = 0
    prediction = np.empty([0,1])
    probability = np.empty([0,n_class])
    num_acc = 0
    with torch.no_grad():
        for data, target, weight in test_loader:
            data, target = data.to(device), target.to(device)
            output = model(data)
            weight = weight.to(device)
            weight_output = torch.einsum('ij,i->ij', (output, weight))
                
            prob = au.my_softmax(weight_output).cpu().numpy()
            probability = np.concatenate((probability, prob))

            criterion = nn.CrossEntropyLoss()
            # loss = criterion(weight_output.clone().detach(), target)
            # test_loss += loss.item()# sum up batch loss
            pred = output.max(1, keepdim=True)[1] # get the index of the max log-probability
            num_acc += len(data)
          
            correct += pred.eq(target.view_as(pred)).sum().item()
            pred = pred.cpu().numpy()
            if np.shape(pred)[0] !=0 :
                prediction = np.concatenate((prediction, pred)) 
            
            
    test_loss = 1.0 - float(correct)/len(test_loader.dataset)
    # if num_acc !=0:
    #
    #     print('Average loss: {:.4f}, Accuracy: {}/{} ({:.0f}%), Abstaining rate: {:.0f}%\n'.format(
    #         test_loss, correct, num_acc,
    #         100. * correct / num_acc, 100. *(1- float(num_acc)/len(test_loader.dataset)) ))
    # else:
    #     print('Abstaining rate is 1.')
    return probability, prediction, 100. * correct / len(test_loader.dataset), test_loss


def test_regression(args, model, Myy, Myx, device, test_loader, mean0, var0):
    model.eval()
    test_loss = 0
    y_prediction = torch.empty([1, 0]).to(device)
    y_var = torch.empty([1, 0]).to(device)
    with torch.no_grad():
        for data, target, weight in test_loader:
            data, target = data.to(device), target.to(device)
            weight = weight.to(device)
            output = model(data)
            
            d = np.shape(data)[0]
            target = torch.reshape(target, (1, d))
            
            meanY, varY = ru.predict_regression(weight, Myy, Myx, output, mean0, var0)
            criterion = nn.MSELoss()
            l2loss = criterion(meanY, target)
            test_loss += torch.sum(l2loss)
            y_prediction = torch.cat([y_prediction, meanY], axis=1)

            y_var = torch.cat([y_var, varY], axis = 1)
            

    test_loss /= len(test_loader.dataset)
    return y_prediction, y_var, test_loss

def test_MSE(args, model, device, test_loader):
    model.eval()
    test_loss = 0
    y_prediction = np.empty([1, 0])
  
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            
            output = model(data)
            
        
            criterion = nn.MSELoss()
            l2loss = criterion(output, target)
            test_loss += torch.sum(l2loss)
            d = np.shape(data)[0]
            meanY = np.reshape(output.cpu(), (1,d))

            y_prediction = np.concatenate((y_prediction, meanY), axis=1)

        
    test_loss /= len(test_loader.dataset)
    # print('Average loss: {:.4f}\n'.format(test_loss))
    # print(target)
    # print(meanY)
    return y_prediction, test_loss


def test_weight_MSE(args, model, device, test_loader):
    model.eval()
    test_loss = 0
    y_prediction = np.empty([1, 0])
  
    with torch.no_grad():
        for data, target, weight, in test_loader:
            data, target, weight = data.to(device), target.to(device), weight.to(device)
            
            output = model(data)
            
            criterion = nn.MSELoss(reduce = False)
            l2loss = (1 - weight)* criterion(output, target)/(weight*weight)
            l2loss = torch.mean(l2loss)
            test_loss += torch.sum(l2loss)
            d = np.shape(data)[0]
            meanY = np.reshape(output.cpu(), (1,d))

            y_prediction = np.concatenate((y_prediction, meanY), axis=1)

        
    test_loss /= len(test_loader.dataset)
    # print('Average loss: {:.4f}\n'.format(test_loss))
    # print(target)
    # print(meanY)
    return y_prediction, test_loss

import random
def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True

def train_validate_test(args, lr,epoch, loss_type, device, use_cuda, train_model, train_loader, test_loader, validate_loader, n_class, lbd,d ,testflag = True,lr1 = 1,lr2 = 1):
    if loss_type == 'logloss':
        best_loss = 10000
        # model = train_model.to(device)#ConvNet().to(device)
        
        optimizer = optim.Adam(train_model.parameters(), lr=lr, weight_decay=lbd)
        for epoch in range(1, epoch + 1):
            train(args, train_model, loss_type, device, train_loader, n_class, optimizer, epoch) 
            probability, predictions, acc, loss = test(args, train_model,loss_type, device, validate_loader, n_class)
        
        # print('\nTesting on test set')
        
        if testflag == True:
        
            probability, predictions, acc, loss = test(args, train_model,loss_type, device, test_loader, n_class)
        
        return probability, predictions, acc, loss
        # f1 = f1_score(test_labels, predictions, average='macro') 
        # acc_per_class = acc_perclass(test_labels, predictions, n_class)
        # print('F1-score:', f1)
        # print('Per class accuracy', acc_per_class)
    elif loss_type == 'regression':
        inbest = 0
        now_best = 0
        best_loss = 100000000
        best_epoch = 1
        Myy = torch.ones((1, 1)).to(device)
        Myx = torch.ones((d+1, 1)).to(device)
        best_Myy = torch.ones((1, 1)).to(device)
        best_Myx = torch.ones((1, 1)).to(device)
        best_model = copy.deepcopy(train_model)
        optimizer = optim.SGD(train_model.parameters(), lr=lr, momentum=args.momentum, weight_decay=lbd)
        for epoch in range(1, epoch + 1):
            Myy, Myx,train_model,grad_yy,grad_yx = train_regression(args, train_model, device, train_loader, optimizer, epoch, Myy, Myx, mean0, var0,d,lr1,lr2) 
            meanY, varY, loss = test_regression(args, train_model, Myy, Myx, device, validate_loader, mean0, var0)
            if loss < best_loss:
                best_epoch = epoch
                best_loss = loss
                best_model  = copy.deepcopy(train_model)
                best_Myx =  copy.deepcopy(Myx)
                best_Myy =  copy.deepcopy(Myy)
                inbest = 1
            if epoch - best_epoch>20:
                if inbest == 1:
                    train_model = best_model
                    Myy = best_Myy
                    Myx = best_Myx
                    now_best = 1
                break
            if grad_yy + grad_yx<=1e-6:
                break
        # print('\nTesting on test set')
        if now_best == 1:
            train_model = best_model
            Myy = best_Myy
            Myx = best_Myx
        if testflag == True:
            meanY, varY, loss = test_regression(args, train_model, Myy, Myx, device, test_loader, mean0, var0)
       
        return train_model, Myy, Myx, meanY, varY, loss
    elif loss_type == 'mse':
        best_loss = 100000000
        best_epoch = 1
        optimizer = optim.Adam(train_model.parameters(), lr=lr, weight_decay=lbd)
        now_best = 0
        for epoch in range(1, epoch + 1):
            inbest = 0
            best_model = copy.deepcopy(train_model)
            # train_MSE(args, train_model, device, train_loader, optimizer, epoch) 

            train_model = train_MSE(args, train_model, device, train_loader, optimizer, epoch) 
            pred_Y, loss = test_MSE(args, train_model,  device, validate_loader)
            if loss < best_loss:
                best_epoch = epoch
                best_loss = loss
                best_model = copy.deepcopy(train_model)
                inbest = 1
            if epoch - best_epoch>20:
                print(epoch)
                if inbest == 1:
                    train_model = best_model
                    now_best = 1
                break
        if now_best == 0:
            train_model = best_model
       
        return train_model, pred_Y, loss

    elif loss_type == 'weighted':
        best_loss = 100000000
        inbest = 0
        best_epoch = 1
        optimizer = optim.Adam(train_model.parameters(), lr=lr, weight_decay=lbd)
        best_model = copy.deepcopy(train_model)
        for epoch in range(1, epoch + 1):
            train_model = train_weight_MSE(args, train_model, device, train_loader, optimizer, epoch) 
            pred_Y, loss = test_weight_MSE(args, train_model,  device, validate_loader)
            if loss < best_loss:
                best_epoch = epoch
                best_loss = loss
                best_model = copy.deepcopy(train_model)
                inbest = 1
            if epoch - best_epoch > 10:
                # print(epoch)
                if inbest == 1:
                    train_model = best_model
                break
       
        return train_model, pred_Y, loss

def round_value(a):
    if a>1:
        a = 1.0
    elif a<0:
        a = 0
    return a


class context_dataset(data.Dataset):
    def __init__(self,context):
        self.context = context
    def __len__(self):
        return len(self.context)
    def __getitem__(self, index):
        return torch.tensor(self.context[index][0])
class context_dataset_eval(data.Dataset):
    def __init__(self,context):
        self.context = context
    def __len__(self):
        return len(self.context)
    def __getitem__(self, index):
        return torch.tensor(self.context[index])
class context_weight_dataset(data.Dataset):
    def __init__(self,context,weight):
        self.context = context
        self.weight = weight
    def __len__(self):
        return len(self.context)
    def __getitem__(self, index):
        # print(self.context[index])
        return torch.tensor(self.context[index]), torch.tensor(self.weight[index])

def predict_target_policy(base_model, data_context, index,device):
    # call base model to estimate the target policy
    dataset_c = context_dataset(data_context)
    dataset_loader = data.DataLoader(dataset_c,batch_size=4096)
    policy_target = torch.empty((0)).to(device)
    for feature in dataset_loader:
        prob = my_softmax(base_model(feature.to(device)))
        policy_target= torch.cat([policy_target,prob[:,index]],axis = 0)
    return policy_target



def my_bound(x):
    if isinstance(x, np.ndarray):  
        x[x>1000] = 1000.0
        x[x<0.0001] = 0.0001
        x[np.isnan(x)] = 0.0001
    elif torch.is_tensor(x):
        x = x.cpu().numpy()
        x[x>1000] = 1000.0
        x[x<0.0001] = 0.0001
        x[np.isnan(x)] = 0.0001
    else:
        if x>1000:
            x = 1000.0
        elif x<0.0001:
            x = 0.0001
    return x

def sample_action(prob, n_class):
    rand = np.random.uniform(0, 1, 1)
    action = 0
    threshold = 0
    
    for j in range(n_class):
    
        threshold = threshold + prob[j]
        
        if rand[0] < threshold:
            action = j
            break
    return action


def sample_action_batch(p, n=1, items=None):
    s = p.cumsum(axis=1)
    r = np.random.rand(p.shape[0], n, 1)
    q = np.expand_dims(s, 1) >= r
    k = q.argmax(axis=-1)
    if items is not None:
        k = np.asarray(items)[k]
    k = k.reshape(len(k))
    return k


def generate_soften_policy(policy,alpha,beta):
    policy = policy.cpu()
    soften_policy = torch.zeros(policy.shape)

    n_class = policy.shape[1]
    u = np.random.uniform(-0.5,0.5,len(policy))

    p_det = alpha + beta * u
    p_other = torch.tensor((1-p_det)/(n_class-1))

    a_det = np.argmax(policy,axis = 1)
    for i in range(n_class):
        soften_policy[:,i] = p_other
    soften_policy[np.arange(len(policy)),a_det] = torch.tensor(p_det)
    return soften_policy


    




# Training settings
parser = argparse.ArgumentParser(description='Covariate Shift')
parser.add_argument('--batch-size', type=int, default=64, metavar='N',
                    help='input batch size for training (default: 64)')
parser.add_argument('--epochs-training', type=int, default=75, metavar='N',
                    help='number of epochs in training (default: 10)')
parser.add_argument('--lr', type=float, default=0.001, metavar='LR',
                    help='learning rate (default: 0.001)')
parser.add_argument('--lr_dm', type=float, default=0.0005, metavar='LR',
                    help='learning rate (default: 0.001)')
parser.add_argument('--lr_dmrobust', type=float, default=0.001, metavar='LR',
                    help='learning rate (default: 0.001)')
parser.add_argument('--lr_robust', type=float, default=0.001, metavar='LR',
                    help='learning rate (default: 0.001)')
parser.add_argument('--lr_mrdr', type=float, default=0.001, metavar='LR',
                    help='learning rate (default: 0.001)')
parser.add_argument('--filename', type=str, default='data/optdigits.csv',
                    help='the file that contains training data')
parser.add_argument('--momentum', type=float, default=0.5, metavar='M',
                    help='SGD momentum (default: 0.5)')
parser.add_argument('--no-cuda', action='store_true', default=False,
                    help='disables CUDA training')
parser.add_argument('--log-interval', type=int, default=100, metavar='N',
                    help='how many batches to wait before logging training status')
parser.add_argument('--mode', type=int, default=1, metavar='N',
                    help='1, policy is a uniform default policy,'
                         '2 and 3 are a policy is a known policy trained from biased samples, '
                         '4 policy is an unknown policy uniform policy, '
                         '5 and 6 are an unknown biased policy ')
parser.add_argument('--dataset', type=int, default=1, metavar='N',
                    help='1, uci, 2 mnist, 3 cifar10')
parser.add_argument('--alpha', type=float, default=0.9, metavar='alpha',
                help='learning rate (default: 0.001)')
parser.add_argument('--beta', type=float, default=0.2, metavar='beta',
                help='learning rate (default: 0.001)')
parser.add_argument('--known_policy', type=int, default=0, metavar='beta',
            help='learning rate (default: 0.001)')


# setup_seed(20220824)

# args = parser.parse_args()
args, unknown = parser.parse_known_args()
