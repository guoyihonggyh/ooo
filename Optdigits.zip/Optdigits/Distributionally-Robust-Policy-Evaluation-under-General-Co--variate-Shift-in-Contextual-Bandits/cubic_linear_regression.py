import random
import numpy as np
import  matplotlib.pyplot as plt
import numpy as np
from scipy.stats import norm

import seaborn as sns
import torch



train_data_number = 500

train_x_mean = 0
test_x_mean = 1

train_x_var = 1
test_x_var = 2

x = np.zeros((train_data_number, 1))
train_x_pdf_on_train_dist = np.zeros((train_data_number))
train_x_pdf_on_test_dist = np.zeros((train_data_number))
for i in range(train_data_number):
    a = np.random.normal(loc=train_x_mean, scale=train_x_var, size=None)
    x[i, 0] = a

    pdf = norm.pdf(a, train_x_mean, train_x_var)
    train_x_pdf_on_train_dist[i] = pdf

    pdf = norm.pdf(a, test_x_mean, test_x_var)
    train_x_pdf_on_test_dist[i] = pdf
train_x_weight = train_x_pdf_on_train_dist / train_x_pdf_on_test_dist

# test data
x_test = np.zeros((500, 1))

test_x_pdf_on_train_dist = np.zeros((500))
test_x_pdf_on_test_dist = np.zeros((500))

for i in range(500):
    a = np.random.normal(loc=test_x_mean, scale=test_x_var, size=None)
    x_test[i, 0] = a

    pdf = norm.pdf(a, train_x_mean, train_x_var)
    test_x_pdf_on_train_dist[i] = pdf

    pdf = norm.pdf(a, test_x_mean, test_x_var)
    test_x_pdf_on_test_dist[i] = pdf

test_x_weight = test_x_pdf_on_train_dist / test_x_pdf_on_test_dist
# plt.scatter(x_test[:,0],x_test[:,1])

from torch import nn
mysoftmax = nn.Softmax(dim=0)
def qudratic_form(x,y):
    return y**3 - 1*y**2*x + 1*y*x**2 + 2*y**2 - 1*y*x - 6*y

def p_y_given_x(x,y):
    v = qudratic_form(x,y)
    return torch.tensor(v)

def dist_of_y(x,prior_p0=0.5, prior_p1 = 0.5):
    v0 = p_y_given_x(x,0) * prior_p0
    v1 = p_y_given_x(x,1) * prior_p1
    p = mysoftmax(torch.tensor([v0,v1])).numpy()
    return p

def get_y(p):
    return np.random.choice(2, 1, p=[p[0],p[1]])[0]






# sample train y
y = []
for x0 in x:
    dist = dist_of_y(x0)
    y.append(get_y(dist))
y = np.array(y)


# sample test y
y_test = []
for x0 in x_test:
    dist = dist_of_y(x0)
    y_test.append(get_y(dist))
y_test = np.array(y_test)

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
import random
from scipy.stats import norm, multivariate_normal

import warnings

warnings.filterwarnings("ignore")
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
# from random import shuffle
from sklearn.utils import shuffle

from sklearn.datasets import load_svmlight_file
from sklearn.preprocessing import StandardScaler, OneHotEncoder, LabelEncoder
import argparse
from sklearn.utils import shuffle
from ope_v4 import *


class WEIGHT_DATA_SET(data.Dataset):
    '''
    dataset class with instance weight
    '''

    def __init__(self, data, reward, weights):
        '''
        weights are same dimensional witi original data
        '''
        self.data = torch.tensor(data)
        self.reward = torch.tensor(reward)
        self.weights = torch.tensor(weights)

    def __getitem__(self, index):
        img = self.data[index]
        target = self.reward[index]
        weight = self.weights[index]
        return img, target, weight

    def __len__(self):
        return len(self.data)


def train_robust_regression(x, y, weight, lr1, lr2, mylambda=0):
    weight_st = my_bound(weight)
    weighted_train = WEIGHT_DATA_SET(x, y, weight)

    train_model = Net(2, 2, 1)

    validate_size = int(0.1 * 500)
    validate_loader = data.DataLoader(data.Subset(weighted_train, range(0, validate_size)),
                                      batch_size=64, shuffle=True)
    # 10% validation set
    train_loader = data.DataLoader(data.Subset(weighted_train, range(validate_size, 450)),
                                   batch_size=64, shuffle=True, )

    train_model, M = train_validate_test(args, args.lr_robust, 400, "regression", 'cpu', 'False',
                                         train_model,
                                         train_loader, None, validate_loader, 1, 0.000,
                                         d=2, testflag=False, lr1=lr1, lr2=lr2, mylambda=mylambda)


    return train_model, M


def predict_regression(weight, M, x, prior_p0=0.5, prior_p1=0.5):
    # v0
    Y = 0
    p0 = -weight * (
                M[0] * Y ** 3 + M[1] * Y ** 2 * x + M[2] * Y * x ** 2 + M[3] * Y ** 2 + M[4] * Y * x + M[5] * Y) * 0.5

    Y = 1
    p1 = -weight * (
                M[0] * Y ** 3 + M[1] * Y ** 2 * x + M[2] * Y * x ** 2 + M[3] * Y ** 2 + M[4] * Y * x + M[5] * Y) * 0.5

    p = mysoftmax(torch.tensor([p0,p1])).numpy()
    meanY = np.random.choice(2, 1, p=p)[0]

    return meanY


# mylambda = torch.tensor([0,0.1,0.3,0]).reshape((4,1))
# # mylambda = torch.tensor([0,0,0.0,0]).reshape((4,1))

from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import LinearRegression



model = LinearRegression().fit(x,y)
res = []
for k in range(10):
    pred = model.predict(x_test)

    res.append(np.mean((pred - y_test) ** 2))
print(np.mean(res),np.var(res))
#
# print(sum(y==1))
# for lr in [2, 1, 0.5, 0.1]:
#
#     model, M = train_robust_regression(x, y, train_x_weight, lr, lr)
#
#     prediction = []
#     for i in range(len(x_test)):
#
#         predy = predict_regression(test_x_weight[i], M, x_test[i], )
#         prediction.append(predy)
#     prediction = np.array(prediction)
#     print(np.mean((prediction - y_test) ** 2))
#     print(M)
#     #
#     # prediction = []
#     # for i in range(len(x_test)):
#     #
#     #     predy = np.random.choice(2, 1, p=[0.5,0.5])[0]
#     #     prediction.append(predy)
#     # prediction = np.array(prediction)
#     # print(np.mean((prediction - y_test) ** 2))